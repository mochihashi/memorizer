# Memorizer

This is a tool that helps you to memorize words or something.
main page - https://mochihashi.github.io/memorizer/

# About

<a target="_blank" href="https://mochihashi.github.io/memorizer/docs/en/">English</a>
&nbsp; <a target="_blank" href="https://mochihashi.github.io/memorizer/docs/cn/">中文</a>
&nbsp; <a target="_blank" href="https://mochihashi.github.io/memorizer/docs/jp/">日本語</a>
&nbsp; <a target="_blank" href="https://mochihashi.github.io/memorizer/docs/kr/">한국어</a>
